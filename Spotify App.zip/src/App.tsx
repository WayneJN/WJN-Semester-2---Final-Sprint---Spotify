import { useState } from 'react';
import { Toaster } from 'sonner';
import { Navbar } from '@/components/layout/Navbar';
import { MusicPlayer } from '@/components/player/MusicPlayer';
import { Home } from '@/components/pages/Home';
import { Charts } from '@/components/pages/Charts';
import { Playlists } from '@/components/pages/Playlists';
import { Songs } from '@/components/pages/Songs';
import { LikedSongsProvider } from '@/components/sections/LikedSongsContext';
import { PlaylistsProvider } from '@/components/sections/PlaylistsContext'; 
import HomePage from '@/components/pages/HomePage';

function App() {
  const [isConnected, setIsConnected] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'charts':
        return <Charts />;
      case 'playlists':
        return <Playlists />;
      case 'songs':
        return <Songs />;
      default:
        return <Home />;
    }
  };

  return (
    <LikedSongsProvider>
      <PlaylistsProvider>
        <div className="min-h-screen bg-background flex">
          {!isConnected ? (
            <HomePage onConnect={() => setIsConnected(true)} />
          ) : (
            <>
              <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
              <main className="flex-1 ml-64 h-screen pb-24 overflow-y-auto">
                <div className="p-8">
                  {renderContent()}
                </div>
              </main>
              <MusicPlayer />
              <Toaster />
            </>
          )}
        </div>
      </PlaylistsProvider>
    </LikedSongsProvider>
  );
}

export default App;
