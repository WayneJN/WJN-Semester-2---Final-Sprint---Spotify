import React from 'react';
import { render } from '@testing-library/react';
import { Card, CardContent } from '@/components/ui/card';

test('renders Card component with children', () => {
  const { getByText } = render(
    <Card>
      <CardContent>
        <p>Card Content</p>
      </CardContent>
    </Card>
  );
  expect(getByText('Card Content')).toBeInTheDocument();
});
