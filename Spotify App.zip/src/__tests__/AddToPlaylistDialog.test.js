import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { AddToPlaylistDialog } from '@/components/sections/AddToPlaylistDialog';
import { PlaylistsProvider } from '@/components/sections/PlaylistsContext';

test('renders AddToPlaylistDialog component', () => {
  render(
    <PlaylistsProvider>
      <AddToPlaylistDialog track={{ title: 'Test Track' }} open={true} onOpenChange={() => {}} />
    </PlaylistsProvider>
  );
  expect(screen.getByText('Add to Playlist')).toBeInTheDocument();
});

test('calls onOpenChange function when dialog is closed', () => {
  const handleOpenChange = jest.fn();
  render(
    <PlaylistsProvider>
      <AddToPlaylistDialog track={{ title: 'Test Track' }} open={true} onOpenChange={handleOpenChange} />
    </PlaylistsProvider>
  );
  fireEvent.click(screen.getByText('Close'));
  expect(handleOpenChange).toHaveBeenCalledTimes(1);
});
