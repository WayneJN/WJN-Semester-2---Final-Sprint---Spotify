import { create } from 'zustand';
import { toast } from 'sonner';
import type { Track } from '@/lib/types';

interface PlayerState {
  currentTrack: Track | null;
  playlist: Track[]; // Array of tracks for the playlist
  currentIndex: number; // Index of the currently playing track
  setCurrentTrack: (track: Track) => void;
  setPlaylist: (tracks: Track[]) => void;
  setNextTrack: () => void;
  setPreviousTrack: () => void;
  toggleLike: (trackId: string) => void;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  currentTrack: null,
  playlist: [],
  currentIndex: 0,

  // Set the current track directly
  setCurrentTrack: (track) => {
    const playlist = get().playlist;
    const index = playlist.findIndex((t) => t.id === track.id);
    set({ currentTrack: track, currentIndex: index });
  },

  // Set the entire playlist
  setPlaylist: (tracks) => {
    set({ playlist: tracks, currentIndex: 0, currentTrack: tracks[0] || null });
  },

  // Skip to the next track
  setNextTrack: () => {
    const { playlist, currentIndex } = get();
    if (playlist.length > 0) {
      const nextIndex = (currentIndex + 1) % playlist.length; // Loop back to start if at the end
      set({ 
        currentIndex: nextIndex, 
        currentTrack: playlist[nextIndex] 
      });
    }
  },

  // Skip to the previous track
  setPreviousTrack: () => {
    const { playlist, currentIndex } = get();
    if (playlist.length > 0) {
      const prevIndex = (currentIndex - 1 + playlist.length) % playlist.length; // Loop back to end if at the start
      set({ 
        currentIndex: prevIndex, 
        currentTrack: playlist[prevIndex] 
      });
    }
  },

  // Toggle the like state of the current track
  toggleLike: (trackId) => {
    const currentTrack = get().currentTrack;
    if (currentTrack && currentTrack.id === trackId) {
      set({
        currentTrack: {
          ...currentTrack,
          isLiked: !currentTrack.isLiked
        }
      });

      toast.success(
        currentTrack.isLiked 
          ? 'Removed from favorite tracks' 
          : 'Added to favorite tracks'
      );
    }
  },
}));
