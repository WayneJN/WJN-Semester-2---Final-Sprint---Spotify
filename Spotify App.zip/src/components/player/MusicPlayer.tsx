import ReactPlayer from 'react-player';
import { useState, useRef } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, 
  Repeat, Shuffle, Volume2, Heart 
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { usePlayerStore } from '@/stores/playerStore';
import { formatTime } from '@/lib/formatTime';
import type { Track } from '@/lib/types';

export function MusicPlayer() {
  const [volume, setVolume] = useState(80);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [trackDuration, setTrackDuration] = useState(0);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);

  const currentTrack = usePlayerStore<Track | null>((state) => state.currentTrack);
  const setNextTrack = usePlayerStore((state) => state.setNextTrack);
  const setPreviousTrack = usePlayerStore((state) => state.setPreviousTrack);
  const toggleLike = usePlayerStore((state) => state.toggleLike);

  const playerRef = useRef<ReactPlayer | null>(null);

  // Handle playback toggle
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  // Handle volume slider change
  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
  };

  // Update current time when slider moves
  const handleTimeChange = (value: number[]) => {
    if (playerRef.current) {
      playerRef.current.seekTo(value[0]);
      setCurrentTime(value[0]);
    }
  };

  // Progress callback from ReactPlayer
  const handleProgress = (state: { playedSeconds: number }) => {
    setCurrentTime(state.playedSeconds);
  };

  // Duration callback from ReactPlayer
  const handleDuration = (duration: number) => {
    setTrackDuration(duration);
  };

  if (!currentTrack) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t z-50">
      <div className="flex items-center justify-between px-8 py-4">
        {/* Track Info */}
        <div className="flex items-center w-1/4">
          <img 
            src={currentTrack.cover} 
            alt={currentTrack.title}
            className="w-14 h-14 rounded object-cover"
          />
          <div className="ml-4">
            <p className="font-medium text-sm">{currentTrack.title}</p>
            <p className="text-xs text-muted-foreground">{currentTrack.artist}</p>
          </div>
          <button 
            onClick={() => toggleLike(currentTrack.id)}
            className="ml-4 hover:text-primary"
          >
            <Heart 
              className="h-5 w-5" 
              fill={currentTrack.isLiked ? "currentColor" : "none"}
            />
          </button>
        </div>

        {/* Player Controls */}
        <div className="flex flex-col items-center w-2/4">
          <div className="flex items-center gap-4 mb-2">
            <button className="text-muted-foreground hover:text-foreground">
              <Shuffle className="h-4 w-4" />
            </button>
            <button onClick={setPreviousTrack} className="text-muted-foreground hover:text-foreground">
              <SkipBack className="h-5 w-5" />
            </button>
            <button 
              onClick={handlePlayPause}
              className="bg-primary text-primary-foreground rounded-full p-2 hover:scale-105 transition"
            >
              {isPlaying ? (
                <Pause className="h-6 w-6" />
              ) : (
                <Play className="h-6 w-6" />
              )}
            </button>
            <button onClick={setNextTrack} className="text-muted-foreground hover:text-foreground">
              <SkipForward className="h-5 w-5" />
            </button>
            <button className="text-muted-foreground hover:text-foreground">
              <Repeat className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center gap-2 w-full">
            <span className="text-xs text-muted-foreground w-12 text-right">
              {formatTime(currentTime)}
            </span>
            <Slider
              value={[currentTime]}
              max={trackDuration} 
              step={1}
              onValueChange={handleTimeChange}
              className="w-full"
            />
            <span className="text-xs text-muted-foreground w-12">
              {formatTime(trackDuration)} 
            </span>
          </div>
        </div>

        {/* Volume Control */}
        <div className="flex items-center justify-end w-1/4">
          <div 
            className="relative"
            onMouseEnter={() => setShowVolumeSlider(true)}
            onMouseLeave={() => setShowVolumeSlider(false)}
          >
            <button className="text-muted-foreground hover:text-foreground">
              <Volume2 className="h-5 w-5" />
            </button>
            {showVolumeSlider && (
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-8 h-32 bg-background border rounded-md p-2">
                <Slider
                  value={[volume]}
                  max={100}
                  step={1}
                  onValueChange={handleVolumeChange}
                  orientation="vertical"
                  className="h-full"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* React Player */}
      <ReactPlayer
        ref={playerRef}
        url={currentTrack.audioUrl}
        playing={isPlaying}
        volume={volume / 100}
        onProgress={handleProgress}
        onDuration={handleDuration}
        onEnded={setNextTrack}
        width="0"
        height="0"
      />
    </div>
  );
}
