import { Home, BarChart3, Sparkles, Radio, Library, ListMusic, Music2, User2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from '@/components/ui/link';

interface NavItemProps {
  page: string;
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  onClick: (page: string) => void;
}

const NavItem = ({ page, icon, label, isActive, onClick }: NavItemProps) => (
  <button 
    onClick={() => onClick(page)}
    className={cn(
      "flex items-center gap-4 px-5 py-3 text-sm font-medium transition-colors w-full text-left",
      "text-muted-foreground hover:text-foreground hover:bg-muted/50",
      isActive && "text-foreground bg-muted"
    )}
  >
    {icon}
    <span>{label}</span>
  </button>
);

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  return (
    <nav className="fixed left-0 top-0 bottom-0 w-64 bg-background border-r z-50">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-6 border-b">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <img src="https://www.pngmart.com/files/22/Spotify-Logo-PNG-Photos.png" alt="Spotify Logo" className="h-8 w-8" />
            <span>Spotify</span>
          </h1>
        </div>


        {/* Main Navigation */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-3 py-2">
            <div className="mb-6">
              <NavItem 
                page="home" 
                icon={<Home className="h-5 w-5" />} 
                label="Home" 
                isActive={currentPage === 'home'}
                onClick={onNavigate}
              />
              <NavItem 
                page="charts" 
                icon={<BarChart3 className="h-5 w-5" />} 
                label="Charts" 
                isActive={currentPage === 'charts'}
                onClick={onNavigate}
              />
              <NavItem 
                page="new" 
                icon={<Sparkles className="h-5 w-5" />} 
                label="New" 
                isActive={currentPage === 'new'}
                onClick={onNavigate}
              />
              <NavItem 
                page="genres" 
                icon={<Radio className="h-5 w-5" />} 
                label="Genres" 
                isActive={currentPage === 'genres'}
                onClick={onNavigate}
              />
            </div>

            <div className="mb-6">
              <h2 className="px-5 mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Your Library
              </h2>
              <NavItem 
                page="playlists" 
                icon={<ListMusic className="h-5 w-5" />} 
                label="Playlists" 
                isActive={currentPage === 'playlists'}
                onClick={onNavigate}
              />
              <NavItem 
                page="songs" 
                icon={<Music2 className="h-5 w-5" />} 
                label="Songs" 
                isActive={currentPage === 'songs'}
                onClick={onNavigate}
              />
              <NavItem 
                page="artists" 
                icon={<User2 className="h-5 w-5" />} 
                label="Artists" 
                isActive={currentPage === 'artists'}
                onClick={onNavigate}
              />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}