import { Library } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';

export function MyCollections() {
  const playlists = [
    { id: 1, title: "Favorite Tracks", tracks: "183 songs", cover: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=300&h=300&fit=crop" },
    { id: 2, title: "Summer Hits", tracks: "95 songs", cover: "https://images.unsplash.com/photo-1534258936925-c58bed479fcb?w=300&h=300&fit=crop" },
    { id: 3, title: "Workout Mix", tracks: "42 songs", cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop" },
    { id: 4, title: "Road Trip", tracks: "127 songs", cover: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=300&h=300&fit=crop" }
  ];

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">My Collection</h2>
          <p className="text-sm text-muted-foreground">Your personal playlists</p>
        </div>
        <Library className="h-5 w-5" />
      </div>
      <ScrollArea>
        <div className="flex space-x-4 pb-4">
          {playlists.map((playlist) => (
            <Card key={playlist.id} className="w-[250px] shrink-0">
              <CardContent className="p-4">
                <img
                  src={playlist.cover}
                  alt={playlist.title}
                  className="w-full aspect-square object-cover rounded-md mb-3"
                />
                <h3 className="font-semibold truncate">{playlist.title}</h3>
                <p className="text-sm text-muted-foreground truncate">
                  {playlist.tracks}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </section>
  );
}