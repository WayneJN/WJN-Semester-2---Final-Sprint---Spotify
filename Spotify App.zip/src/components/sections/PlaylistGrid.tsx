import { Card, CardContent } from '@/components/ui/card';
import { Play, Music2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import type { Playlist } from '@/components/pages/Playlists';

interface PlaylistGridProps {
  playlists: Playlist[];
  onDeletePlaylist: (id: string) => void;
}

export function PlaylistGrid({ playlists, onDeletePlaylist }: PlaylistGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {playlists.map((playlist) => (
        <Card key={playlist.id} className="group cursor-pointer overflow-hidden relative">
          <CardContent className="p-0">
            <div className="relative">
              <img
                src={playlist.cover}
                alt={playlist.title}
                className="w-full aspect-square object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button size="icon" variant="secondary" className="rounded-full">
                  <Play className="h-6 w-6" />
                </Button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold truncate">{playlist.title}</h3>
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <Music2 className="h-4 w-4" />
                {playlist.trackCount} tracks
              </p>
            </div>
          </CardContent>
          <Button
            size="icon"
            variant="destructive"
            className="absolute bg-black bottom-2 right-2"
            onClick={() => onDeletePlaylist(playlist.id)}
          >
            <FontAwesomeIcon icon={faTrash} className="h-6 w-6" />
          </Button>
        </Card>
      ))}
    </div>
  );
}
