import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Music2, Save } from 'lucide-react';
import type { Playlist } from '@/components/pages/Playlists';

interface CreatePlaylistDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreatePlaylist: (playlist: Omit<Playlist, 'id'>) => void;
}

export function CreatePlaylistDialog({ 
  open, 
  onOpenChange, 
  onCreatePlaylist 
}: CreatePlaylistDialogProps) {
  const [title, setTitle] = useState('New Playlist');
  
  const handleCreate = () => {
    onCreatePlaylist({
      title,
      trackCount: 0,
      cover: 'https://images.unsplash.com/photo-1534258936925-c58bed479fcb?w=300&h=300&fit=crop'
    });
    setTitle('New Playlist');
  };

  const handleClear = () => {
    setTitle('New Playlist');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Music2 className="h-8 w-8" />
            <DialogTitle>Create New Playlist</DialogTitle>
          </div>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Playlist Title"
              className="text-lg font-medium"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <Button variant="outline" size="icon" onClick={handleClear} className="text-blue bg-blue-1000 px-9 py-2 rounded-md">
              Clear Form
            </Button>
            
            <Button onClick={handleCreate} className="bg-green-500 text-white">
              <Save className="h-4 w-4 mr-2" />
              Save Playlist
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
