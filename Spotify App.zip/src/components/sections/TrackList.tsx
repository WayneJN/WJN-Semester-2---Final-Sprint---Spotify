import { useState } from 'react';
import { Music2, Play } from 'lucide-react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart as faHeartOutline, faPlus, faTrash } from '@fortawesome/free-solid-svg-icons';
import { faHeart as faHeartSolid } from '@fortawesome/free-regular-svg-icons';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AddToPlaylistDialog } from './AddToPlaylistDialog';
import type { Track } from '@/lib/types';
import { useLikedSongs } from '@/components/sections/LikedSongsContext';

interface TrackListProps {
  tracks?: Track[];
  onLike?: (trackId: string) => void;
  onUnlike?: (trackId: string) => void;
  onDelete?: (trackId: string) => void;
  showLikeButton?: boolean;
  showDeleteButton?: boolean;
  playlistId?: string;
}

const defaultTracks: Track[] = [
  {
    id: '1',
    title: "As It Was",
    artist: "Harry Styles",
    duration: "2:47",
    cover: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=50&h=50&fit=crop",
    audioUrl: "https://www.youtube.com/watch?v=V1Z586zoeeE&t=1s",
    isLiked: false
  },
  {
    id: '2',
    title: "Anti-Hero",
    artist: "Taylor Swift",
    duration: "3:20",
    cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
    audioUrl: "https://www.youtube.com/watch?v=b1kbLwvqugk",
    isLiked: false
  }
];

export function TrackList({ 
  tracks = defaultTracks, 
  onDelete,
  showLikeButton = false,
  showDeleteButton = false,
  playlistId 
}: TrackListProps) {
  const { toggleLike } = useLikedSongs();
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);
  const [showAddToPlaylist, setShowAddToPlaylist] = useState(false);

  const handleLikeToggle = (track: Track) => {
    toggleLike(track);
    toast.success(track.isLiked ? 'Removed from favorite tracks' : 'Added to favorite tracks');
  };

  const handleAddToPlaylist = (track: Track) => {
    setSelectedTrack(track);
    setShowAddToPlaylist(true);
  };

  const handleDelete = (trackId: string) => {
    onDelete?.(trackId);
    toast.success('Track removed from playlist');
  };

  return (
    <Card>
      <ScrollArea className="h-[800px]">
        <CardContent className="p-6">
          {tracks.map((track, index) => (
            <div
              key={track.id}
              className="flex items-center gap-4 p-2 hover:bg-muted/50 rounded-md group cursor-pointer"
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="relative">
                  <img
                    src={track.cover}
                    alt={track.title}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="h-4 w-4 text-white" />
                  </div>
                </div>
                <span className="w-8 text-sm text-muted-foreground">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <p className="font-medium">{track.title}</p>
                  <p className="text-sm text-muted-foreground">{track.artist}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div style={{ width: '500px' }}></div> {/* Adding white space */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-4">
                  {showLikeButton && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleLikeToggle(track)}
                    >
                      <FontAwesomeIcon 
                        icon={track.isLiked ? faHeartSolid : faHeartOutline} 
                        className="h-4 w-4" 
                      />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleAddToPlaylist(track)}
                  >
                    <FontAwesomeIcon 
                      icon={faPlus} 
                      className="h-4 w-4" 
                    />
                  </Button>
                  {showDeleteButton && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDelete(track.id)}
                    >
                      <FontAwesomeIcon icon={faTrash} className="h-4 w-4" />
                    </Button>
                  )}
                  <Music2 className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground w-16">
                    {track.duration}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </ScrollArea>

      <AddToPlaylistDialog
        track={selectedTrack}
        open={showAddToPlaylist}
        onOpenChange={setShowAddToPlaylist}
        excludePlaylistId={playlistId}
      />
    </Card>
  );
}
