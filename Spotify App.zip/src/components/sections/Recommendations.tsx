import { Sparkles } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';

export function Recommendations() {
  const recommendations = [
    { id: 1, title: "Chill Mix", description: "Based on your recent listening", cover: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&h=300&fit=crop" },
    { id: 2, title: "Discover Weekly", description: "Your weekly mixtape of fresh music", cover: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop" },
    { id: 3, title: "Release Radar", description: "Catch all the latest music", cover: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop" },
    { id: 4, title: "Daily Mix 1", description: "Made for you", cover: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop" }
  ];

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">You May Like</h2>
          <p className="text-sm text-muted-foreground">Based on your recent activity</p>
        </div>
        <Sparkles className="h-5 w-5" />
      </div>
      <ScrollArea>
        <div className="flex space-x-4 pb-4">
          {recommendations.map((item) => (
            <Card key={item.id} className="w-[250px] shrink-0">
              <CardContent className="p-4">
                <img
                  src={item.cover}
                  alt={item.title}
                  className="w-full aspect-square object-cover rounded-md mb-3"
                />
                <h3 className="font-semibold truncate">{item.title}</h3>
                <p className="text-sm text-muted-foreground truncate">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </section>
  );
}