// AddToPlaylistDialog.tsx
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Music2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { usePlaylists } from '@/components/sections/PlaylistsContext';
import type { Track } from '@/lib/types';

interface AddToPlaylistDialogProps {
  track: Track | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  excludePlaylistId?: string; // Ensure this prop is defined
}

export function AddToPlaylistDialog({
  track,
  open,
  onOpenChange,
  excludePlaylistId
}: AddToPlaylistDialogProps) {
  const { playlists, addTrackToPlaylist } = usePlaylists();

  const handleAddToPlaylist = (playlistId: string) => {
    if (track) {
      addTrackToPlaylist(playlistId, track);
      toast.success('New track added to playlist');
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Music2 className="h-8 w-8" />
            <DialogTitle>Add to Playlist</DialogTitle>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[400px] pr-4">
          <div className="space-y-4">
            {playlists
              .filter(playlist => playlist.id !== excludePlaylistId) // Use this filter
              .map(playlist => (
                <div
                  key={playlist.id}
                  className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-md cursor-pointer"
                  onClick={() => handleAddToPlaylist(playlist.id)}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={playlist.cover}
                      alt={playlist.title}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div>
                      <p className="font-medium">{playlist.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {playlist.trackCount} tracks
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
