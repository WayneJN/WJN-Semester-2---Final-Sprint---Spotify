import { ChevronDown } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface CountrySelectProps {
  selectedCountry: string;
  onCountryChange: (country: string) => void;
}

export function CountrySelect({ selectedCountry, onCountryChange }: CountrySelectProps) {
  const countries = [
    'Global',
    'United States',
    'United Kingdom',
    'Japan',
    'Germany',
    'France',
    'Canada',
    'Australia',
    'Brazil',
    'South Korea'
  ];

  return (
    <Select value={selectedCountry} onValueChange={onCountryChange}>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder="Select country" />
      </SelectTrigger>
      <SelectContent>
        {countries.map((country) => (
          <SelectItem key={country} value={country}>
            {country}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}