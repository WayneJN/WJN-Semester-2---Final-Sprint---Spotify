import { Radio } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export function Genres() {
  const genres = [
    { id: 1, name: "Hip-Hop", image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop" },
    { id: 2, name: "Pop", image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop" },
    { id: 3, name: "Rock", image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop" },
    { id: 4, name: "R&B", image: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&h=300&fit=crop" },
    { id: 5, name: "Dance", image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop" },
    { id: 6, name: "Latin", image: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=300&h=300&fit=crop" },
    ];

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Genres & Moods</h2>
        <Radio className="h-5 w-5" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        {genres.map((genre) => (
          <Card key={genre.id} className="group cursor-pointer overflow-hidden">
            <CardContent className="p-0 relative">
              <img
                src={genre.image}
                alt={genre.name}
                className="w-full aspect-square object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <h3 className="text-white font-bold text-lg">{genre.name}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}