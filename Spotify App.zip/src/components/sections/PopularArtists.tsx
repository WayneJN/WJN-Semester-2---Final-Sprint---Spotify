import { Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function PopularArtists() {
  const artists = [
    { id: 1, name: "Taylor Swift", followers: "88.5M", image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=100&h=100&fit=crop" },
    { id: 2, name: "The Weeknd", followers: "52.3M", image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=100&h=100&fit=crop" },
    { id: 3, name: "Drake", followers: "73.1M", image: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=100&h=100&fit=crop" },
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle>Popular Artists</CardTitle>
        <Users className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {artists.map((artist) => (
            <div key={artist.id} className="flex items-center space-x-4">
              <img
                src={artist.image}
                alt={artist.name}
                className="h-10 w-10 rounded-full object-cover"
              />
              <div className="flex-1 space-y-1">
                <p className="font-medium leading-none">{artist.name}</p>
                <p className="text-sm text-muted-foreground">{artist.followers} followers</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}