import { useEffect, useState } from 'react';
import { Music2, Play, Heart } from 'lucide-react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { AddToPlaylistDialog } from '@/components/sections/AddToPlaylistDialog';
import { Button } from '@/components/ui/button';
import { useLikedSongs } from '@/components/sections/LikedSongsContext';
import { Playlist } from '@/components/pages/Playlists';
import type { Track as GlobalTrack } from '@/lib/types';

interface ChartListProps {
  country: string;
}

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  cover: string;
  audioUrl: string;
  isLiked: boolean;
  liked?: boolean;
}

export function ChartList({ country }: ChartListProps) {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);
  const [showAddToPlaylist, setShowAddToPlaylist] = useState(false);
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);
  const [, setPlaylists] = useState<Playlist[]>([]);
  const { toggleLike } = useLikedSongs();

  useEffect(() => {
    const fetchPlaylists = () => {
      const storedPlaylists = localStorage.getItem('playlists');
      if (storedPlaylists) {
        setPlaylists(JSON.parse(storedPlaylists));
      }
    };

    fetchPlaylists();
  }, []);

  const shuffleTracks = (tracks: Track[]): Track[] => {
    const shuffled = tracks.slice().sort(() => Math.random() - 0.5);
    return shuffled.map((track, index) => ({ ...track, id: (index + 1).toString() }));
  };

  useEffect(() => {
    const fetchImages = async () => {
      try {


        const mockTracks: Track[] = [
          // Existing Tracks
          {
            id: '1',
            title: "As It Was",
            artist: "Harry Styles",
            duration: "2:47",
            cover: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/as-it-was.mp3",
            isLiked: false
          },
          {
            id: '2',
            title: "Anti-Hero",
            artist: "Taylor Swift",
            duration: "3:20",
            cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/anti-hero.mp3",
            isLiked: false
          },
          {
            id: '3',
            title: "Peaches",
            artist: "Justin Bieber",
            duration: "3:18",
            cover: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/peaches.mp3",
            isLiked: false
          },
          {
            id: '4',
            title: "Save Your Tears",
            artist: "The Weeknd",
            duration: "3:35",
            cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/save-your-tears.mp3",
            isLiked: false
          },
          {
            id: '5',
            title: "Drivers License",
            artist: "Olivia Rodrigo",
            duration: "4:02",
            cover: "https://images.unsplash.com/photo-1552740739-bcfa5b4f9626?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/drivers-license.mp3",
            isLiked: false
          },
          // New Tracks
          {
            id: '6',
            title: "Blinding Lights",
            artist: "The Weeknd",
            duration: "3:20",
            cover: "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/blinding-lights.mp3",
            isLiked: false
          },
          {
            id: '7',
            title: "Levitating",
            artist: "Dua Lipa",
            duration: "3:24",
            cover: "https://images.unsplash.com/photo-1509057199576-632a47484ece?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/levitating.mp3",
            isLiked: false
          },
          {
            id: '8',
            title: "Watermelon Sugar",
            artist: "Harry Styles",
            duration: "2:54",
            cover: "https://images.unsplash.com/photo-1526407270725-97eaa3d4bca8?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/watermelon-sugar.mp3",
            isLiked: false
          },
          {
            id: '9',
            title: "Bad Guy",
            artist: "Billie Eilish",
            duration: "3:14",
            cover: "https://images.unsplash.com/photo-1482357349063-9b4e1b6cded6?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/bad-guy.mp3",
            isLiked: false
          },
          {
            id: '10',
            title: "Circles",
            artist: "Post Malone",
            duration: "3:35",
            cover: "https://images.unsplash.com/photo-1482357349063-9b4e1b6cded6?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/circles.mp3",
            isLiked: false
          },
          {
            id: '11',
            title: "Shivers",
            artist: "Ed Sheeran",
            duration: "3:27",
            cover: "https://images.unsplash.com/photo-1502767089025-6572583495b0?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/shivers.mp3",
            isLiked: false
          },
          {
            id: '12',
            title: "Good 4 U",
            artist: "Olivia Rodrigo",
            duration: "2:58",
            cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/good-4-u.mp3",
            isLiked: false
          },
          {
            id: '13',
            title: "Montero (Call Me By Your Name)",
            artist: "Lil Nas X",
            duration: "2:17",
            cover: "https://images.unsplash.com/photo-1544717305-996b815c338c?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/montero.mp3",
            isLiked: false
          },
          {
            id: '14',
            title: "Stay",
            artist: "The Kid LAROI, Justin Bieber",
            duration: "2:21",
            cover: "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/stay.mp3",
            isLiked: false
          },
          {
            id: '15',
            title: "Industry Baby",
            artist: "Lil Nas X, Jack Harlow",
            duration: "3:32",
            cover: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/industry-baby.mp3",
            isLiked: false
          },
          {
            id: '16',
            title: "Heat Waves",
            artist: "Glass Animals",
            duration: "3:58",
            cover: "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/heat-waves.mp3",
            isLiked: false
          },
          {
            id: '17',
            title: "Don't Start Now",
            artist: "Dua Lipa",
            duration: "3:03",
            cover: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/dont-start-now.mp3",
            isLiked: false
          },
          {
            id: '18',
            title: "Without You",
            artist: "The Kid LAROI",
            duration: "2:41",
            cover: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/without-you.mp3",
            isLiked: false
          },
          {
            id: '19',
            title: "Positions",
            artist: "Ariana Grande",
            duration: "2:52",
            cover: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/positions.mp3",
            isLiked: false
          },
          {
            id: '20',
            title: "Save Your Tears (Remix)",
            artist: "The Weeknd, Ariana Grande",
            duration: "3:11",
            cover: "https://images.unsplash.com/photo-1502767089025-6572583495b0?w=50&h=50&fit=crop",
            audioUrl: "https://www.example.com/audio/save-your-tears-remix.mp3",
            isLiked: false
          }
        ];
        

        setTracks(shuffleTracks(mockTracks));
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    fetchImages();
  }, [country]);

  const handleLikeToggle = (track: Track) => {
    toggleLike(track as GlobalTrack);
    toast.success(track.liked ? "Removed from favorite tracks" : "Added to favorite tracks");
  };

  const handleAddToPlaylist = (track: Track) => {
    setSelectedTrack(track);
    setShowAddToPlaylist(true);
  };

  const handleTrackClick = (track: Track) => {
    if (currentAudio) {
      currentAudio.pause();
    }
    const newAudio = new Audio(track.audioUrl);
    newAudio.play().catch(error => console.error("Audio playback error:", error));
    setCurrentAudio(newAudio);
  };

  return (
    <Card className="w-full h-full">
      <ScrollArea className="h-full">
        <CardContent className="p-6">
          {tracks.map((track, index) => (
            <div
              key={track.id}
              className="flex items-center gap-4 p-2 hover:bg-muted/50 rounded-md group cursor-pointer"
              onClick={() => handleTrackClick(track)}
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="relative">
                  <img
                    src={track.cover}
                    alt={track.title}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="h-4 w-4 text-white" />
                  </div>
                </div>
                <span className="w-8 text-sm text-muted-foreground">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <p className="font-medium">{track.title}</p>
                  <p className="text-sm text-muted-foreground">{track.artist}</p>
                </div>
                <div style={{ width: '600px' }}></div>
              </div>
              <div className="flex items-center gap-4">
                <Music2 className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100" />
                <span className="text-sm text-muted-foreground">
                  {track.duration}
                </span>
                <Heart 
                  className={`w-4 h-4 cursor-pointer ${track.liked ? 'fill-red-500' : 'text-muted-foreground'}`} 
                  onClick={() => handleLikeToggle(track)}
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="opacity-0 group-hover:opacity-100"
                  onClick={() => handleAddToPlaylist(track)}
                >
                  <FontAwesomeIcon 
                    icon={faPlus} 
                    className="h-4 w-4" 
                  />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </ScrollArea>

      <AddToPlaylistDialog
        track={selectedTrack}
        open={showAddToPlaylist}
        onOpenChange={setShowAddToPlaylist}
      />

    </Card>
  );
}
