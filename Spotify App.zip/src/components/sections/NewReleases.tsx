import { Album, Play } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { usePlayerStore } from '@/stores/playerStore';
import type { Track } from '@/lib/types';

export function NewReleases() {
  const setCurrentTrack = usePlayerStore(state => state.setCurrentTrack);
  
  const releases: Track[] = [
    { 
      id: '1',
      title: "Midnight",
      artist: "Taylor Swift",
      duration: "180",  // Duration in seconds
      cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
      isLiked: false,
      audioUrl: "https://www.youtube.com/watch?v=Odh9ddPUkEY&t=1s"
    },
    {
      id: '2',
      title: "Blinding Lights",
      artist: "The Weeknd",
      duration: "200",  // Duration in seconds
      cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop",
      isLiked: false,
      audioUrl: "https://www.youtube.com/watch?v=4NRXx6U8ABQ"
    },
    {
      id: '3',
      title: "Levitating",
      artist: "Dua Lipa",
      duration: "203",  // Duration in seconds
      cover: "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?w=300&h=300&fit=crop",
      isLiked: false,
      audioUrl: "https://www.youtube.com/watch?v=TUVcZfQe-Kw"
    },
    {
      id: '4',
      title: "Watermelon Sugar",
      artist: "Harry Styles",
      duration: "174",  // Duration in seconds
      cover: "https://images.unsplash.com/photo-1519985176271-adb1088fa94c?w=300&h=300&fit=crop",
      isLiked: false,
      audioUrl: "https://www.youtube.com/watch?v=E07s5ZYygMg"
    },
    {
      id: '5',
      title: "Good 4 U",
      artist: "Olivia Rodrigo",
      duration: "178",  // Duration in seconds
      cover: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=300&h=300&fit=crop",
      isLiked: false,
      audioUrl: "https://www.youtube.com/watch?v=gNi_6U5Pm_o"
    },
    // ... more releases
  ];

  const handlePlay = (release: Track) => {
    setCurrentTrack(release);
  };

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Suggested New Releases</h2>
          <p className="text-sm text-muted-foreground">Fresh music just for you</p>
        </div>
        <Album className="h-5 w-5 text-muted-foreground" />
      </div>

      <ScrollArea className="w-full">
        <div className="flex space-x-6">
          {releases.map((release) => (
            <div
              key={release.id}
              className="group w-[200px] shrink-0 cursor-pointer"
            >
              <div className="relative">
                <img
                  src={release.cover}
                  alt={release.title}
                  className="w-full aspect-square object-cover rounded-md transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-md flex items-center justify-center">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="rounded-full"
                    onClick={() => handlePlay(release)}
                  >
                    <Play className="h-6 w-6" />
                  </Button>
                </div>
              </div>
              <div className="mt-3">
                <h3 className="font-semibold truncate">{release.title}</h3>
                <p className="text-sm text-muted-foreground">{release.artist}</p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </section>
  )}