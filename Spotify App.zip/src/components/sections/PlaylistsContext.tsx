// PlaylistsContext.tsx
import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Playlist {
  id: string;
  title: string;
  trackCount: number;
  cover: string;
  tracks: Track[];
}

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  cover: string;
  liked?: boolean;
}

interface PlaylistsContextProps {
  playlists: Playlist[];
  addTrackToPlaylist: (playlistId: string, track: Track) => void;
}

const PlaylistsContext = createContext<PlaylistsContextProps | undefined>(undefined);

export const PlaylistsProvider = ({ children }: { children: ReactNode }) => {
  const [playlists, setPlaylists] = useState<Playlist[]>([
    {
      id: '1',
      title: 'Lo-Fi Beats',
      trackCount: 42,
      cover: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=300&h=300&fit=crop',
      tracks: [],
    },
    {
      id: '2',
      title: 'Good Morning Jazz',
      trackCount: 36,
      cover: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop',
      tracks: [],
    },
  ]);

  const addTrackToPlaylist = (playlistId: string, track: Track) => {
    setPlaylists(prevPlaylists =>
      prevPlaylists.map(playlist =>
        playlist.id === playlistId
          ? { ...playlist, tracks: [...playlist.tracks, track], trackCount: playlist.trackCount + 1 }
          : playlist
      )
    );
  };

  return (
    <PlaylistsContext.Provider value={{ playlists, addTrackToPlaylist }}>
      {children}
    </PlaylistsContext.Provider>
  );
};

export const usePlaylists = () => {
  const context = useContext(PlaylistsContext);
  if (!context) {
    throw new Error('usePlaylists must be used within a PlaylistsProvider');
  }
  return context;
};
