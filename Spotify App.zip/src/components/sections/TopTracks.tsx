import { Music } from 'lucide-react'; // Add Heart to the import
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { usePlayerStore } from '@/stores/playerStore';
import { useState } from 'react';
import type { Track } from '@/lib/types';

export function TopTracks() {
  const setCurrentTrack = usePlayerStore(state => state.setCurrentTrack);
  
  const [tracks] = useState<Track[]>([
    {
      id: '1',
      title: "As It Was",
      artist: "Harry Styles",
      duration: "2:47",
      cover: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=V1Z586zoeeE&t=1s",
      isLiked: false
    },
    {
      id: '2',
      title: "Anti-Hero",
      artist: "Taylor Swift",
      duration: "3:20",
      cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=b1kbLwvqugk",
      isLiked: false
    },
    {
      id: '3',
      title: "Peaches",
      artist: "Justin Bieber",
      duration: "3:18",
      cover: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=tQ0yjYUFKAE",
      isLiked: false
    },
    {
      id: '4',
      title: "Save Your Tears",
      artist: "The Weeknd",
      duration: "3:35",
      cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=XXYlFuWEuKI",
      isLiked: false
    },
    {
      id: '5',
      title: "Drivers License",
      artist: "Olivia Rodrigo",
      duration: "4:02",
      cover: "https://images.unsplash.com/photo-1552740739-bcfa5b4f9626?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=ZmDBbnmKpqQ",
      isLiked: false
    },
    {
      id: '6',
      title: "Levitating",
      artist: "Dua Lipa",
      duration: "3:23",
      cover: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=TUVcZfQe-Kw",
      isLiked: false
    },
    {
      id: '7',
      title: "Montero (Call Me By Your Name)",
      artist: "Lil Nas X",
      duration: "2:17",
      cover: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=6swmTBVI83k",
      isLiked: false
    },
    {
      id: '8',
      title: "Stay",
      artist: "The Kid LAROI & Justin Bieber",
      duration: "2:21",
      cover: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=kTJczUoc26U",
      isLiked: false
    },
    {
      id: '9',
      title: "Good 4 U",
      artist: "Olivia Rodrigo",
      duration: "2:58",
      cover: "https://images.unsplash.com/photo-1516542076529-1ea3854896b9?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=gNi_6U5Pm_o",
      isLiked: false
    },
    {
      id: '10',
      title: "Shivers",
      artist: "Ed Sheeran",
      duration: "3:27",
      cover: "https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=Il0S8BoucSA",
      isLiked: false
    },
    {
      id: '11',
      title: "Industry Baby",
      artist: "Lil Nas X & Jack Harlow",
      duration: "3:32",
      cover: "https://images.unsplash.com/photo-1500522144261-ea64433bbe27?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=UTHLKHL_whs",
      isLiked: false
    },
    {
      id: '12',
      title: "Bad Habits",
      artist: "Ed Sheeran",
      duration: "3:51",
      cover: "https://images.unsplash.com/photo-1517256064527-09c73fc73e53?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=orJSJGHjBLI",
      isLiked: false
    },
    {
      id: '13',
      title: "Kiss Me More",
      artist: "Doja Cat feat. SZA",
      duration: "3:28",
      cover: "https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=0EVVKs6DQLo",
      isLiked: false
    },
    {
      id: '14',
      title: "Butter",
      artist: "BTS",
      duration: "2:45",
      cover: "https://images.unsplash.com/photo-1516338405000-4e1b582d80a4?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=WMweEpGlu_U",
      isLiked: false
    },
    {
      id: '15',
      title: "Blinding Lights",
      artist: "The Weeknd",
      duration: "3:20",
      cover: "https://images.unsplash.com/photo-1517256064527-09c73fc73e53?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=4NRXx6U8ABQ",
      isLiked: false
    },
    {
      id: '16',
      title: "Deja Vu",
      artist: "Olivia Rodrigo",
      duration: "3:35",
      cover: "https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=cii6ruuycQA",
      isLiked: false
    },
    {
      id: '17',
      title: "Happier Than Ever",
      artist: "Billie Eilish",
      duration: "4:58",
      cover: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=5GJWxDKyk3A",
      isLiked: false
    },
    {
      id: '18',
      title: "Positions",
      artist: "Ariana Grande",
      duration: "2:52",
      cover: "https://images.unsplash.com/photo-1526170375888-4d8ecf77b99f?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=tcYodQoapMg",
      isLiked: false
    },
    {
      id: '19',
      title: "Mood",
      artist: "24kGoldn feat. iann dior",
      duration: "2:20",
      cover: "https://images.unsplash.com/photo-1526170375887-4d8ecf77b99f?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=GrAchTdepsU",
      isLiked: false
    },
    {
      id: '20',
      title: "Heat Waves",
      artist: "Glass Animals",
      duration: "3:59",
      cover: "https://images.unsplash.com/photo-1526170375886-4d8ecf77b99f?w=50&h=50&fit=crop",
      audioUrl: "https://www.youtube.com/watch?v=mrdPIkVtWqM",
      isLiked: false
    }
  ]);
  


  const handleTrackClick = (track: Track) => {
    setCurrentTrack(track);
  };

  return (
    <Card className="h-[600px] overflow-auto border-none shadow-none">
      <CardHeader className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center justify-between">
          <CardTitle>Hot Tracks - Global 50</CardTitle>
          <Music className="h-4 w-4 text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {tracks.map((track, index) => (
            <div
              key={track.id}
              onClick={() => handleTrackClick(track)}
              className="flex items-center gap-4 p-2 hover:bg-muted/50 rounded-md group cursor-pointer"
            >
              <img
                src={track.cover}
                alt={track.title}
                className="w-12 h-12 rounded object-cover"
              />
              <span className="text-muted-foreground w-6">{index + 1}</span>
              <div className="flex-1 space-y-1">
                <p className="font-medium leading-none">{track.title}</p>
                <p className="text-sm text-muted-foreground">{track.artist}</p>
              </div>
             
              <div className="text-sm text-muted-foreground">{track.duration}</div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
