import React, { createContext, useState, useContext, ReactNode } from 'react';
import type { Track } from '@/lib/types';

interface LikedSongsContextProps {
  likedSongs: Track[];
  toggleLike: (track: Track) => void;
}

const LikedSongsContext = createContext<LikedSongsContextProps | undefined>(undefined);

export const LikedSongsProvider = ({ children }: { children: ReactNode }) => {
  const [likedSongs, setLikedSongs] = useState<Track[]>([]);

  const toggleLike = (track: Track) => {
    setLikedSongs((prev) =>
      prev.find((t) => t.id === track.id)
        ? prev.filter((t) => t.id !== track.id)
        : [...prev, { ...track, isLiked: true }]
    );
  };

  return (
    <LikedSongsContext.Provider value={{ likedSongs, toggleLike }}>
      {children}
    </LikedSongsContext.Provider>
  );
};

export const useLikedSongs = () => {
  const context = useContext(LikedSongsContext);
  if (!context) {
    throw new Error('useLikedSongs must be used within a LikedSongsProvider');
  }
  return context;
};
