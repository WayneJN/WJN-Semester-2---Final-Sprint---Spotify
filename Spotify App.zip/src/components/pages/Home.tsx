import { useEffect } from 'react';
import { NewReleases } from '@/components/sections/NewReleases';
import { TopTracks } from '@/components/sections/TopTracks';
import { Genres } from '@/components/sections/Genres';
import { FeaturedPlaylists } from '@/components/sections/FeaturedPlaylists';
import { Recommendations } from '@/components/sections/Recommendations';
import { MyCollections } from '@/components/sections/MyCollections';

export function Home() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="space-y-12">
      <NewReleases />
      
      <div className="grid grid-cols-[1fr,400px] gap-8">
        <TopTracks />
        <Genres />
      </div>
      
      <FeaturedPlaylists />
      <Recommendations />
      <MyCollections />
    </div>
  );
}