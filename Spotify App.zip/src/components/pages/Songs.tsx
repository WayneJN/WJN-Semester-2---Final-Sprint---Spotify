import { Heart } from 'lucide-react';
import { TrackList } from '@/components/sections/TrackList';
import { useLikedSongs } from '@/components/sections/LikedSongsContext';

export function Songs() {
  const { likedSongs } = useLikedSongs();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Favorite Songs</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {likedSongs.length} liked songs
          </p>
        </div>
        <Heart className="h-6 w-6 text-primary" fill="currentColor" />
      </div>
      
      <TrackList 
        tracks={likedSongs.length > 0 ? likedSongs : undefined}
        showLikeButton
        showDeleteButton
      />
    </div>
  );
}
