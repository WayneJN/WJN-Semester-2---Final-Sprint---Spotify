import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { PlaylistGrid } from '@/components/sections/PlaylistGrid';
import { CreatePlaylistDialog } from '@/components/sections/CreatePlaylistDialog';
import { Button } from '@/components/ui/button';

export interface Playlist {
  id: string;
  title: string;
  trackCount: number;
  cover: string;
  tracks?: Track[]; // Include tracks in the Playlist interface
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  cover: string;
  liked?: boolean;
}

// Initial playlists
const initialPlaylists: Playlist[] = [
  { id: '1', title: 'Lo-Fi Beats', trackCount: 42, cover: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=300&h=300&fit=crop', tracks: [] },
  { id: '2', title: 'Good Morning Jazz', trackCount: 36, cover: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop', tracks: [] },
  { id: '3', title: 'Chill Vibes', trackCount: 28, cover: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop', tracks: [] },
  { id: '4', title: 'Workout Mix', trackCount: 50, cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop', tracks: [] },
  { id: '5', title: 'Road Trip', trackCount: 65, cover: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=300&h=300&fit=crop', tracks: [] },
  { id: '6', title: 'Study Session', trackCount: 32, cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop', tracks: [] },
  { id: '7', title: 'Party Hits', trackCount: 45, cover: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&h=300&fit=crop', tracks: [] }
];

export function Playlists() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const storedPlaylists = localStorage.getItem('playlists');
    if (storedPlaylists) {
      const parsedStoredPlaylists = JSON.parse(storedPlaylists);
      return [
        ...initialPlaylists,
        ...parsedStoredPlaylists.filter((storedPlaylist: Playlist) => 
          !initialPlaylists.some(initialPlaylist => initialPlaylist.id === storedPlaylist.id)
        )
      ];
    }
    return initialPlaylists;
  });

  useEffect(() => {
    // Save playlists to local storage whenever they are updated
    localStorage.setItem('playlists', JSON.stringify(playlists));
  }, [playlists]);

  const handleCreatePlaylist = (newPlaylist: Omit<Playlist, 'id'>) => {
    const playlist = {
      ...newPlaylist,
      id: Math.random().toString(36).substr(2, 9),
      tracks: [] // Initialize tracks as an empty array
    };
    setPlaylists([...playlists, playlist]);
    setIsDialogOpen(false);
  };

  const handleDeletePlaylist = (id: string) => {
    const updatedPlaylists = playlists.filter(playlist => playlist.id !== id);
    setPlaylists(updatedPlaylists);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">My Playlists</h1>
        <Button onClick={() => setIsDialogOpen(true)} variant="outline" size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Create Playlist
        </Button>
      </div>
      <PlaylistGrid playlists={playlists} onDeletePlaylist={handleDeletePlaylist} />
      <CreatePlaylistDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onCreatePlaylist={handleCreatePlaylist}
      />
    </div>
  );
}
