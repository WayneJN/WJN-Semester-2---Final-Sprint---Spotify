import { useState } from 'react';
import { ChartList } from '@/components/sections/ChartList';
import { CountrySelect } from '@/components/sections/CountrySelect';

export function Charts() {
  const [selectedCountry, setSelectedCountry] = useState('Global');

  return (
    <div className="w-full h-screen flex flex-col p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Charts</h1>
        <CountrySelect 
          selectedCountry={selectedCountry} 
          onCountryChange={setSelectedCountry} 
        />
      </div>
      <div className="flex-1">
        <ChartList country={selectedCountry} /> {/* Pass country prop */}
      </div>
    </div>
  );
}
