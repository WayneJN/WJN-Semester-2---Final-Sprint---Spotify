import React, { CSSProperties } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpotify } from '@fortawesome/free-brands-svg-icons';

const HomePage = ({ onConnect }: { onConnect: () => void }) => {
  const containerStyle: CSSProperties = {
    backgroundColor: 'black',
    height: '100vh',
    width: '100vw',
    margin: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Poppins, sans-serif',
    color: 'white',
    textAlign: 'center',
  };

  const imgStyle: CSSProperties = {
    margin: '70px 0 40px 0',
  };

  const pStyle: CSSProperties = {
    fontFamily: 'Raleway ExtraBold',
    fontSize: '35px',
  };

  const greenButtonStyle: CSSProperties = {
    fontSize: '17px',
    fontFamily: 'Raleway ExtraBold',
    backgroundColor: '#32CD32',
    width: '270px',
    padding: '5px 0',
    margin: '12px 0 7px 0',
    borderRadius: '30px',
    border: 'none',
  };

  const lowerButtonStyle: CSSProperties = {
    color: 'white',
    fontFamily: 'Raleway ExtraBold',
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '17px',
    margin: '10px 0',
  };

  return (
    <div style={containerStyle}>
      <div>
        <FontAwesomeIcon icon={faSpotify} size="5x" style={imgStyle} />
        <p style={pStyle}>Welcome to Spotify.</p>
        <button style={greenButtonStyle} onClick={onConnect}>Connect</button><br />
      </div>
    </div>
  );
};

export default HomePage;
