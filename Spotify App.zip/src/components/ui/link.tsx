import { forwardRef } from 'react';
import { cn } from '@/lib/utils';

export interface LinkProps
  extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  children: React.ReactNode;
}

const Link = forwardRef<HTMLAnchorElement, LinkProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <a
        ref={ref}
        className={cn('no-underline outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2', className)}
        {...props}
      >
        {children}
      </a>
    );
  }
);
Link.displayName = 'Link';

export { Link };