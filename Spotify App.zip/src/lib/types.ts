// src/lib/types.ts

export interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  cover: string;
  audioUrl: string;
  isLiked: boolean; // Remove the optional marker
}

export interface Playlist {
  id: string;
  title: string;
  trackCount: number;
  cover: string;
  tracks?: Track[];
}
